#include<raylib.h>
#include<stdio.h>
#include<stdbool.h>
#include<math.h>

#define MAX_BALLS 10


//true = right, false = left
typedef struct {
	float x;
	float y;
	float walkspeed;
	float x_dis;
	float y_dis;
	float width;
	float height;
	bool direction;
	Texture2D wizard;
}Player;

typedef struct {
	Vector2 pos;
	Vector2 vel;
	Vector2 spos;
	bool active;
}Ball;

Ball magicballs[MAX_BALLS];

void player_create(Player* player) {
	player->x = GetScreenWidth()/2;
	player->y = GetScreenHeight()/2;
	player->walkspeed = 5;
	player->direction = true;
	player->x_dis = GetScreenWidth()/4;
	player->y_dis = GetScreenHeight() / 4;
	player->width = 48;
	player->height = 72;
	player->wizard = LoadTexture("magic.png");
}

bool CheckWallCollision(Rectangle nextRect, float x_dis, float y_dis) {
	for (int i = 0; i < 11; i++) {
		for (int j = 0; j < 11; j++) {
			if ((!i || !j) || i == 10 || j == 10) {
				Rectangle wallRect = {
					(float)(j * 48 + (int)x_dis),
					(float)(i * 48 + (int)y_dis),
					48, 48
				};
				if (CheckCollisionRecs(nextRect, wallRect)) return true;
			}
		}
	}
	return false;
}

void shootball(Player* player) {
	for (int i = 0; i < MAX_BALLS; i++) {
		if (!magicballs[i].active) {
			magicballs[i].active = true;
			magicballs[i].pos = (Vector2){ player->x,player->y };

			Vector2 mouse = { GetMouseX(),GetMouseY() };
			float dis = sqrt((player->x - mouse.x) * (player->x - mouse.x) + (player->y - mouse.y) * (player->y - mouse.y));
			Vector2 dir = { (player->x - mouse.x) / dis, (player->y - mouse.y) / dis };

			magicballs[i].vel = (Vector2){ dir.x * 8,dir.y * 8 };
		}
	}
}

void player_update(Player* player) {
	if (IsKeyDown(KEY_A)) {
		if (player->x < GetScreenWidth() / 2 - 100)
			player->x_dis += player->walkspeed;
		else
			player->x -= player->walkspeed;
	}
	if (IsKeyDown(KEY_D)) {
		if (player->x > GetScreenWidth() / 2 + 100)
			player->x_dis -= player->walkspeed;
		else
			player->x += player->walkspeed;
	}
	if (IsKeyDown(KEY_W)) {
		if (player->y < GetScreenHeight() / 2 - 100)
			player->y_dis += player->walkspeed;
		else
			player->y -= player->walkspeed;
	}
	if (IsKeyDown(KEY_S)) {
		if (player->y > GetScreenHeight() / 2 + 100)
			player->y_dis -= player->walkspeed;
		else
			player->y += player->walkspeed;
	}

	player->direction = (GetMouseX() - player->x > 0);

	if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
		shootball(player);
	}


}

void player_draw(Player* player) {

	if (player->direction ) {
		DrawTextureRec(player->wizard, (Rectangle) { 0, 0, -player->wizard.width, player->wizard.height }, (Vector2) { player->x - player->width / 2, player->y - player->height / 2 }, WHITE);
		//DrawRectangle(player->x - player->width/2, player->y - player->height/2, player->width, player->height, RED);
	}
	else {
		DrawTexture(player->wizard, player->x - player->width / 2, player->y - player->height / 2, WHITE);
		//DrawRectangle(player->x - player->width/2, player->y - player->height/2, player->width, player->height, BLUE);
	}
	DrawRectangle(player->x, player->y + player->height/2 , 2, 2, BLACK);
}

void player_mouse() {
	DrawRectangle(GetMouseX()-5,GetMouseY()-5, 10, 10, BLACK);
}

void block_update(Player* player) {
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			if ((i + j) % 2 == 0) {
				DrawRectangle(i * 48 + (int)(player->x_dis), j * 48 + (int)(player->y_dis), 48, 48, GREEN);
			} else {
				DrawRectangle(i * 48 + (int)(player->x_dis), j * 48 + (int)(player->y_dis), 48, 48, PINK);
			}
		}
	}
}



void wall_update(Player* player) {
	Rectangle playerRect = {
		player->x - player->width / 2,
		player->y - 16,
		player->width,
		48
	};

	for (int i = 0; i < 11; i++) {
		for (int j = 0; j < 11; j++) {
			if ((!i || !j) || i == 10 || j == 10) {
				Rectangle wallRect = {
					(float)(j * 48 + (int)(player->x_dis)),
					(float)(i * 48 + (int)(player->y_dis)),
					48, 48
				};
				DrawRectangleRec(wallRect, YELLOW);
				if (CheckCollisionRecs(playerRect, wallRect)) {
					// ������ ���� ����� ��
					if (playerRect.x < wallRect.x && playerRect.x + playerRect.width > wallRect.x && (wallRect.y <= player->y && player->y <= wallRect.y + 48)) {
						player->x = wallRect.x - player->width / 2;
					}
					// ���� ��
					else if (playerRect.x > wallRect.x && playerRect.x < wallRect.x + wallRect.width && (wallRect.y <= player->y && player->y <= wallRect.y + 48)) {
						player->x = wallRect.x + wallRect.width + player->width / 2;
					}
					// ����
					if (playerRect.y < wallRect.y && playerRect.y + playerRect.height > wallRect.y && (wallRect.x <= player->x && player->x <= wallRect.x + 48)) {
						player->y = wallRect.y - player->height / 2;
					}
					// �Ʒ���
					else if (playerRect.y > wallRect.y && playerRect.y < wallRect.y + wallRect.height && (wallRect.x <= player->x && player->x <= wallRect.x + 48)) {
						player->y = wallRect.y + wallRect.height + 16;
					}
				}
			}
		}
	}
}

typedef enum {
	normal
}staffs;

void staff_update(Player* player, Texture2D* staff) {
	Rectangle staff_Rec = { 0, 0, player->direction ? -staff->width : staff->width, staff->height };
	Vector2 pos = player->direction ? (Vector2) {player->x + player->width / 4 ,player->y - player->height / 2 + 15}
									: (Vector2) {player->x - player->width * 3 / 4 + 10,player->y - player->height / 2 + 15};
	DrawTextureRec(*staff, staff_Rec, pos, WHITE);
}


void ball_update() {
	for (int i = 0; i < MAX_BALLS; i++) {
		if (magicballs[i].active) {
			magicballs[i].pos.x -= magicballs[i].vel.x;
			magicballs[i].pos.y -= magicballs[i].vel.y;
			DrawCircle((int)magicballs[i].pos.x, (int)magicballs[i].pos.y, 5, BLUE);
			if (magicballs[i].pos.x < 0 || magicballs[i].pos.x > GetScreenWidth() || magicballs[i].pos.y < 0 || magicballs[i].pos.y > GetScreenHeight()) {
				magicballs[i].active = false;
			}
		}
	}
}

int main() {
	InitWindow(1600, 900, "PlayerMove");
	SetTargetFPS(60);
	Player player;
	player_create(&player);
	Image Staff = LoadImage("staff.png");
	ImageColorReplace(&Staff, WHITE, BLANK);
	Texture2D staff = LoadTextureFromImage(Staff);
	Texture2D boss = LoadTexture("boss.png");
	while (!WindowShouldClose()) {
		BeginDrawing();

		ClearBackground(GRAY);
		player_update(&player);
		block_update(&player);
		wall_update(&player);
		
		player_draw(&player);
		staff_update(&player, &staff);
		ball_update();
		player_mouse();
		//ball_update(&magicballs[0]);
		DrawTexture(boss, player.x_dis + boss.width, player.y_dis + boss.height, WHITE);

		EndDrawing();
	}
	CloseWindow();
	return 0;
}
